from typing import Literal


class DownloadStates:
    downloading: str = "downloading"
    success: str = "success"
    error: str = "error"
    moved: str = "moved"
    stalled: str = "stalled"
    failed_import: str = "failed-import"
    imported: str = "imported"


class RecordStates:
    wanted: str = "wanted"
    downloading: str = "downloading"
    downloaded: str = "downloaded"
    imported: str = "imported"
    manual: str = "manual"
    removed: str = "removed"


class SearchTermTypes:
    record: Literal["record"] = "record"
    track: Literal["track"] = "track"


class Events:
    wanted_missing: str = "wanted--missing"
    wanted_unmet: str = "wanted--unmet"
    import_success: str = "import--success"
    import_error: str = "import--error"
    import_lidarr: str = "import--lidarr"
    download_added: str = "download--added"
    download_success: str = "download--success"
    download_error: str = "download--error"
    download_stalled: str = "download--stalled"
    search_performed: str = "search--performed"
    removed: str = "wanted-removed"
