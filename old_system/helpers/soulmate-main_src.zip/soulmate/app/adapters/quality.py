from typing import Generator

from app.media import get_supported_file_types
from app.models.internal import PotentialRecord
from app.models.lidarr import Quality, QualityConfig, QualityProfile


def _get_quality_objects(quality_profile: QualityProfile) -> Generator[Quality, None, None]:
    for item in quality_profile.items[::-1]:
        if isinstance(item, Quality):
            yield item
            continue

        for quality in item.items[::-1]:
            yield quality


def get_quality(quality_profile: QualityProfile, potential: PotentialRecord) -> Quality | None:
    if all(
        [
            potential.media_info.file_type == "MP3",
            potential.media_info.quality,
            potential.media_info.vbr is False,
            f"MP3-{potential.media_info.quality}" in get_supported_file_types(),
        ]
    ):
        # Here we are ignoring max and min size checks, because we are fairly certain it should be ok
        for quality in _get_quality_objects(quality_profile):
            if quality.name == f"MP3-{potential.media_info.quality}":
                return quality

    fallback_quality = None
    for quality in _get_quality_objects(quality_profile):
        if quality.name == "Unknown":
            fallback_quality = quality

        if potential.media_info.file_type not in quality.config.allowed_file_types:
            continue

        # mp3 generally has more information provided by slskd, so if information is missing we want to mark quality as unknown
        if quality.name.startswith("MP3") and potential.media_info.kbps == 0:
            continue

        if quality.config.max_size and potential.media_info.kbps > quality.config.max_size:
            continue

        if potential.media_info.kbps < quality.config.min_size:
            continue

        if "VBR" in quality.name and potential.media_info.vbr is False:
            continue

        # attempt to try to figure out vbr releases
        if quality.name.startswith("MP3") and "VBR" not in quality.name and potential.media_info.vbr is True:
            continue

        # we do not want to assume it's 24bit unless expressly stated
        if quality.name == "FLAC 24bit" and not potential.media_info.quality.startswith("24"):
            continue

        if quality.name == "FLAC" and potential.media_info.quality.startswith("24"):
            continue

        return quality

    return fallback_quality


def raw_to_quality_profile(raw_definitions: list[dict], raw_profile: dict) -> QualityProfile:
    file_types = get_supported_file_types()

    definitions: dict[str, QualityConfig] = {}
    for raw_definition in raw_definitions:
        config = QualityConfig.model_validate(raw_definition)
        config.allowed_file_types = file_types[config.name]
        definitions[config.name] = config

    record = QualityProfile.model_validate(raw_profile)
    weight = 0
    for group in record.items:
        if isinstance(group, Quality):
            group.weight = weight
            weight += 1
            group.config = definitions[group.name]
            continue

        for quality in group.items:
            quality.weight = weight
            weight += 1
            quality.config = definitions[quality.name]

    return record
