import re

from rapidfuzz import fuzz, process

from app.media import supported_media_file
from app.models.internal import PotentialRecord, TrackCheck
from app.models.lidarr import Record, RecordRelease, Track

_TRACK_NUMBER_REGEX = r"^\d+([-.]\d+)*[-.\s]*"


def _get_possible_titles(original_title: str) -> list[str]:
    possible_titles = []
    # remove file ending

    for title in (original_title, original_title.replace("_", " ")):
        title = title.rsplit(".", 1)[0]
        title_with_numbers = title

        # remove any numbers at start of string, and add that one first
        title = re.sub(_TRACK_NUMBER_REGEX, "", title)
        if title not in possible_titles:
            possible_titles.append(title)

        if title_with_numbers not in possible_titles:
            possible_titles.append(title_with_numbers)

        # sometimes translations etc are added in paranthesis
        # and sometimes artist and/or album is present in filename
        for delimiter, position in (
            ("(", 0),
            ("feat.", 0),
            ("featuring", 0),
            ("[", 0),
            ("-", -1),
        ):
            if delimiter not in title.casefold():
                continue
            pruned_title = title.casefold().rsplit(delimiter, 1)[position].strip()
            if pruned_title not in possible_titles:
                possible_titles.append(pruned_title)

    return possible_titles


def _get_track_check(filename: str) -> TrackCheck:
    check = TrackCheck(original_title=filename.rsplit("\\", 1)[-1])

    track_number_match = re.search(_TRACK_NUMBER_REGEX, check.original_title)
    if track_number_match:
        check.track_number = track_number_match.group(0).strip(" .-").lstrip("0")

    # try title as it is
    check.possible_titles = _get_possible_titles(check.original_title)

    return check


def _compare_tracks(
    record: Record,
    lidarr_tracks: list[Track],
    slskd_checks: list[TrackCheck],
) -> bool:
    tracks = []

    for t in lidarr_tracks:
        title = t.title
        tracks.append(title.casefold())

    for check in slskd_checks:
        track_found = False
        for title in check.possible_titles:
            if track_found:
                continue

            result = process.extractOne(title.casefold(), tracks, scorer=fuzz.WRatio)
            if not result:
                continue

            track_title = result[0]
            matched = max(
                fuzz.ratio(title.casefold(), x.casefold())
                for x in (
                    track_title,
                    f"{record.artist.name} {record.title} {track_title}",
                    f"{record.title} {track_title}",
                    f"{record.artist.name} {track_title}",
                )
            )
            if matched > 80:
                tracks.remove(track_title)
                track_found = True

    return len(tracks) == 0


def _release_sorter(release: RecordRelease) -> int:
    sort_score = 200 if release.status == "Official" else 100
    sort_score += release.track_count

    return sort_score


def match_potential_release(record: Record, potential: PotentialRecord) -> bool:
    for release in sorted(record.releases, key=lambda x: _release_sorter(x), reverse=True):
        # if lidarr is set up to only monitor a specific release, skip others
        if record.any_release_ok is False and release.monitored is False:
            continue

        # if the track count is different, it won't import anyway, so we can skip it
        if release.track_count != potential.media_info.audio_file_count:
            continue

        track_checks = []
        for slskd_file in potential.slskd_files:
            if not supported_media_file(slskd_file.filename):
                continue
            track_checks.append(_get_track_check(slskd_file.filename))

        matched = _compare_tracks(
            record,
            release.tracks,
            track_checks,
        )
        if matched:
            return True

    return False
