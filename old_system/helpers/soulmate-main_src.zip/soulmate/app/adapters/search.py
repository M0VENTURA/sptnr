import contextlib
from collections import Counter, defaultdict

from app.media import supported_media_file
from app.models.internal import MediaInfo, PotentialRecord
from app.models.slskd import File, SearchResult


def _determine_media_type(files: list[File]) -> MediaInfo:
    media_type = MediaInfo()

    total_size = 0
    total_length = 0
    results = {
        "file_types": [],
        "quality": defaultdict(list),
    }

    for file_entry in files:
        file_type = file_entry.filename.upper().rsplit(".", 1)[-1]
        if not supported_media_file(file_type):
            continue

        if file_entry.length:
            total_size += file_entry.size / 1024  # kilobytes
            total_length += file_entry.length

        media_type.audio_file_count += 1
        results["file_types"].append(file_type)
        quality = []
        for value in (file_entry.bit_rate, file_entry.bit_depth, file_entry.sample_rate):
            if value in ("", None):
                continue
            quality.append(value)

        if len(quality) > 0:
            results["quality"][file_type].append("/".join([str(x) for x in quality]))

        if file_entry.is_variable_bitrate:
            media_type.vbr = True

    with contextlib.suppress(IndexError):
        media_type.file_type = Counter(results["file_types"]).most_common(1)[0][0]
    with contextlib.suppress(IndexError):
        media_type.quality = Counter(results["quality"][media_type.file_type]).most_common(1)[0][0]

    if total_length and total_size:
        # convert to kilobits, then divide by length
        media_type.kbps = int(total_size * 8 / total_length)

    return media_type


def get_potential_records(results: list[SearchResult]) -> list[PotentialRecord]:
    output: list[PotentialRecord] = []

    for result in results:
        directories = defaultdict(list)
        if result.file_count == result.locked_file_count:
            continue

        for file_entry in result.files:
            if file_entry.is_locked:
                continue

            file_directory = file_entry.filename.rsplit("\\", 1)[0]
            directories[file_directory].append(file_entry)

        for directory, files in directories.items():
            potential_record = PotentialRecord(
                username=result.username,
                directory=directory,
                media_info=_determine_media_type(files),
                slskd_files=files,
                local_directory=directory.rsplit("\\", 1)[-1],
                has_free_upload_slot=result.has_free_upload_slot,
            )
            output.append(potential_record)

    return sorted(output, key=lambda x: x.media_info.kbps, reverse=True)
