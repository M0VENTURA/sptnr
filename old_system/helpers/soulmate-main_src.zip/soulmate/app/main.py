import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncGenerator

import uvicorn
from fastapi import FastAPI
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from tortoise import Tortoise

from app.api.router import api_router
from app.config import settings
from app.gui.router import gui_router
from app.log.middleware import SoulmateFastAPIMiddleware
from app.log.setup import setup_logging
from app.migrations import run_migrations
from app.tasks import scheduler
from app.version import soulmate_version


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator:
    setup_logging(
        set_level_for_loggers=[
            {
                "logger_name": "apscheduler",
                "log_level": "ERROR",
            },
            {
                "logger_name": "httpx",
                "log_level": "WARNING",
            },
        ]
    )

    run_migrations()

    await Tortoise.init(
        db_url=f"sqlite://{settings.config_path / 'soulmate.db'}",
        modules={"models": ["app.models.db"]},
    )
    await Tortoise.generate_schemas()

    scheduler.start()

    yield

    # add a small sleep to after shutdown since it doesnt seem to work well
    scheduler.shutdown(wait=True)
    await Tortoise.close_connections()


app = FastAPI(
    title="soulmate",
    lifespan=lifespan,
    version=soulmate_version(),
)
app.add_middleware(SoulmateFastAPIMiddleware)


@app.get("/_/health", include_in_schema=False)
def health_check() -> JSONResponse:
    return JSONResponse({"status": "ok"})


app.mount("/static", StaticFiles(directory=Path(__file__).parent / "static"), name="static")
app.include_router(api_router)
app.include_router(gui_router)


@app.get("/", include_in_schema=False)
async def index() -> RedirectResponse:
    return RedirectResponse("/gui/records")


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",  # noqa: S104
        port=7373,
        proxy_headers=True,
        forwarded_allow_ips="*",
        reload=bool(not os.environ.get("PRODUCTION")),
    )
