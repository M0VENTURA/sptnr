from pathlib import Path

from pydantic import BaseModel, Field, field_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict
from typing_extensions import Annotated


class Lidarr(BaseModel):
    url: str = ""
    key: str = ""
    download_path: Path = Path("")
    public_url: str = ""


class Slskd(BaseModel):
    url: str = ""
    key: str = ""
    download_path: Path = Path("")
    public_url: str = ""
    enabled: bool = True


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_nested_delimiter="__")
    lidarr: Lidarr = Field(default_factory=Lidarr)
    slskd: Slskd = Field(default_factory=Slskd)
    config_path: Path = Path("/config")
    max_concurrent_downloads: int = 5
    initial_wait_minutes: int = 0
    require_manual_imports: bool = False
    additional_searches: Annotated[list[str], NoDecode] = Field(default=[])
    search_missing: bool = True
    search_unmet: bool = False
    stalled_download_minutes: int = 40
    ignored_lidarr_album_types: Annotated[list[str], NoDecode] = Field(default=[])
    automatic_lidarr_import: bool = True
    delete_errored_downloads: bool = False
    delete_failed_imports: bool = False

    @field_validator("additional_searches", "ignored_lidarr_album_types", mode="before")
    @classmethod
    def split_strings_to_list(cls, v: str) -> list[str]:
        if not v:
            return []
        return [x for x in v.split(",")]


settings = Settings()
