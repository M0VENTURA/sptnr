import functools

from app.lidarr.api import lidarr_api_get_media_management

_CACHE = {
    "allowed_media_file_types": [],
    "extra_file_types": [],
}


def supported_media_file(filename: str) -> str:
    file_type = filename.rsplit(".")[-1].upper()

    if file_type in _supprted_media_files():
        return file_type

    return ""


@functools.cache
def get_supported_file_types() -> dict:
    """
    Returns supported file types per lidarr quality setting
    These are hard coded as they are also hard coded in lidarr
    """
    return {
        "Unknown": [],
        "MP3-8": ["MP3", "MP2"],
        "MP3-16": ["MP3", "MP2"],
        "MP3-24": ["MP3", "MP2"],
        "MP3-32": ["MP3", "MP2"],
        "MP3-40": ["MP3", "MP2"],
        "MP3-48": ["MP3", "MP2"],
        "MP3-56": ["MP3", "MP2"],
        "MP3-64": ["MP3", "MP2"],
        "MP3-80": ["MP3", "MP2"],
        "MP3-96": ["MP3", "MP2"],
        "MP3-112": ["MP3", "MP2"],
        "MP3-128": ["MP3", "MP2"],
        "OGG Vorbis Q5": ["OGG", "OGA", "OPUS"],
        "MP3-160": ["MP3", "MP2"],
        "MP3-192": ["MP3", "MP2"],
        "OGG Vorbis Q6": ["OGG", "OGA", "OPUS"],
        "AAC-192": ["M4A", "MP4", "M4B", "M4P"],
        "WMA": ["WMA"],
        "MP3-224": ["MP3", "MP2"],
        "OGG Vorbis Q7": ["OGG", "OGA", "OPUS"],
        "MP3-VBR-V2": ["MP3", "MP2"],
        "MP3-256": ["MP3", "MP2"],
        "OGG Vorbis Q8": ["OGG", "OGA", "OPUS"],
        "AAC-256": ["M4A", "MP4", "M4B", "M4P"],
        "MP3-VBR-V0": ["MP3", "MP2"],
        "AAC-VBR": ["M4A", "MP4", "M4B", "M4P"],
        "MP3-320": ["MP3", "MP2"],
        "OGG Vorbis Q9": ["OGG", "OGA", "OPUS"],
        "AAC-320": ["M4A", "MP4", "M4B", "M4P"],
        "OGG Vorbis Q10": ["OGG", "OGA", "OPUS"],
        "FLAC": ["FLAC"],
        "ALAC": ["M4A"],
        "APE": ["APE"],
        "WavPack": ["WV"],
        "FLAC 24bit": ["FLAC"],
        "ALAC 24bit": ["M4A"],
        "WAV": ["WAV"],
    }


@functools.cache
def _supprted_media_files() -> set[str]:
    quality_config = get_supported_file_types()
    file_types = set()
    for supported_type_list in quality_config.values():
        for supported_type in supported_type_list:
            file_types.add(supported_type)

    return file_types


def _parse_extra_file_types(extra_file_types: str) -> list[str]:
    return [x.upper().strip(" .") for x in extra_file_types.split(",")]


async def should_download_file(filename: str) -> bool:
    # TODO: perhaps should update every now and then
    if not _CACHE["extra_file_types"]:
        media_management = await lidarr_api_get_media_management()

        _CACHE["extra_file_types"] += _parse_extra_file_types(media_management["extraFileExtensions"])

    file_type = filename.rsplit(".")[-1].upper()

    return bool(file_type in _CACHE["extra_file_types"] or supported_media_file(file_type))
