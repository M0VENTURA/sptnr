from app.lidarr.api import lidarr_api_get_wanted
from app.models.lidarr import Record


async def get_wanted(max_hits: int = 0, missing: bool = True) -> list[Record]:
    page_size = 50
    if max_hits and max_hits <= 50:
        page_size = max_hits

    wanted = []

    max_pages = 1
    page = 1
    while page <= max_pages:
        raw_wanted = await lidarr_api_get_wanted(
            page=page,
            page_size=page_size,
            missing=missing,
        )
        total_records = raw_wanted.get("totalRecords") or 0
        if total_records:
            max_pages = int(total_records / page_size) + 1

        wanted += [Record.model_validate(x) for x in raw_wanted.get("records") or []]
        if max_hits and len(wanted) >= max_hits:
            wanted = wanted[:max_hits]
            break

        page += 1

    return wanted
