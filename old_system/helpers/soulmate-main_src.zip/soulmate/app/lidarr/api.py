import functools

import httpx

from app.config import settings


@functools.cache
def _get_lidarr_client() -> httpx.AsyncClient:
    return httpx.AsyncClient(timeout=httpx.Timeout(20))


@functools.cache
def _get_lidarr_headers() -> dict[str, str]:
    return {
        "X-API-Key": settings.lidarr.key,
        "Content-Type": "application/json",
    }


@functools.cache
def _lidarr_api_url() -> str:
    return settings.lidarr.url.strip("/") + "/api/v1"


async def lidarr_api_get_album(record_id: int) -> dict:
    client = _get_lidarr_client()

    response = await client.get(
        f"{_lidarr_api_url()}/album/{record_id}",
        headers=_get_lidarr_headers(),
    )
    response.raise_for_status()

    return response.json()


async def lidarr_api_get_tracks(album_release_id: int) -> list:
    client = _get_lidarr_client()

    response = await client.get(
        f"{_lidarr_api_url()}/track",
        headers=_get_lidarr_headers(),
        params={
            "albumReleaseId": album_release_id,
        },
    )
    response.raise_for_status()

    return response.json()


async def lidarr_api_get_track_file(record_id: int) -> list[dict]:
    client = _get_lidarr_client()

    response = await client.get(
        f"{_lidarr_api_url()}/trackFile",
        headers=_get_lidarr_headers(),
        params={
            "albumId": record_id,
        },
    )
    response.raise_for_status()

    return response.json()


async def lidarr_api_get_media_management() -> dict:
    client = _get_lidarr_client()
    response = await client.get(
        f"{_lidarr_api_url()}/config/mediamanagement",
        headers=_get_lidarr_headers(),
    )
    response.raise_for_status()

    return response.json()


async def lidarr_api_get_wanted(
    page: int,
    page_size: int,
    missing: bool = True,
) -> dict:
    client = _get_lidarr_client()
    url = f"{_lidarr_api_url()}/wanted/missing" if missing else f"{_lidarr_api_url()}/wanted/cutoff"

    response = await client.get(
        url,
        headers=_get_lidarr_headers(),
        params={
            "sortDirection": "ascending",
            "sortKey": "albums.title",
            "page": page,
            "pageSize": page_size,
        },
    )
    response.raise_for_status()

    return response.json()


async def lidarr_api_import_record(path: str) -> dict:
    client = _get_lidarr_client()

    data = {
        "name": "DownloadedAlbumsScan",
        "path": path,
    }
    response = await client.post(
        f"{_lidarr_api_url()}/command",
        headers=_get_lidarr_headers(),
        json=data,
    )
    response.raise_for_status()

    return response.json()


async def lidarr_api_get_import(command_id: int) -> dict:
    client = _get_lidarr_client()

    response = await client.get(
        f"{_lidarr_api_url()}/command/{command_id}",
        headers=_get_lidarr_headers(),
    )
    response.raise_for_status()

    return response.json()


async def lidarr_api_get_quality_profile(profile_id: int) -> dict:
    client = _get_lidarr_client()

    response = await client.get(
        f"{_lidarr_api_url()}/qualityprofile/{profile_id}",
        headers=_get_lidarr_headers(),
    )
    response.raise_for_status()

    return response.json()


async def lidarr_api_get_quality_definition() -> list:
    client = _get_lidarr_client()

    response = await client.get(
        f"{_lidarr_api_url()}/qualitydefinition",
        headers=_get_lidarr_headers(),
    )
    response.raise_for_status()

    return response.json()


async def lidarr_api_get_queue_details() -> list:
    client = _get_lidarr_client()

    response = await client.get(
        f"{_lidarr_api_url()}/queue/details",
        headers=_get_lidarr_headers(),
    )
    response.raise_for_status()

    return response.json()


async def lidarr_api_get_connection_status() -> str:
    client = _get_lidarr_client()

    response = await client.get(
        f"{settings.lidarr.url.strip('/')}/api",
        headers=_get_lidarr_headers(),
    )

    response.raise_for_status()

    return response.json().get("current") or ""
