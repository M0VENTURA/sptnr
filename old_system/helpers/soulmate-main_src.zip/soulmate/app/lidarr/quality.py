from app.adapters.quality import raw_to_quality_profile
from app.lidarr.api import lidarr_api_get_quality_definition, lidarr_api_get_quality_profile, lidarr_api_get_track_file
from app.models.lidarr import QualityProfile


async def get_quality_profile(profile_id: int) -> QualityProfile:
    raw_definitions = await lidarr_api_get_quality_definition()
    raw_profile = await lidarr_api_get_quality_profile(profile_id)

    return raw_to_quality_profile(raw_definitions, raw_profile)


async def get_current_record_quality(record_id: int) -> list[str]:
    track_file = await lidarr_api_get_track_file(record_id)
    current_quality = set()

    for file_entry in track_file:
        quality_name = file_entry.get("quality", {}).get("quality", {}).get("name") or ""
        if quality_name:
            current_quality.add(quality_name)

    return list(current_quality)
