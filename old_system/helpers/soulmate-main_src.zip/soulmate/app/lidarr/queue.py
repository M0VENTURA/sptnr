from app.lidarr.api import lidarr_api_get_queue_details


async def in_queue(record_id: int) -> bool:
    queue = await lidarr_api_get_queue_details()

    return any(item.get("albumId") == record_id for item in queue)
