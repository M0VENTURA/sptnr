from app.lidarr.api import lidarr_api_get_album, lidarr_api_get_tracks
from app.models.lidarr import Record, Track


async def get_record(record_id: int) -> Record:
    raw_record = await lidarr_api_get_album(record_id)

    record = Record.model_validate(raw_record)
    for release in record.releases:
        raw_tracks = await lidarr_api_get_tracks(release.id)
        for o in raw_tracks:
            release.tracks.append(Track.model_validate(o))

    return record
