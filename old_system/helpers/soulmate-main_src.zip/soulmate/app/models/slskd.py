from pydantic import BaseModel, Field


class File(BaseModel):
    filename: str
    is_locked: bool = Field(default=False, validation_alias="isLocked")
    is_variable_bitrate: bool | None = Field(default=None, validation_alias="isVariableBitRate")
    bit_depth: int | None = Field(default=None, validation_alias="bitDepth")
    bit_rate: int | None = Field(default=None, validation_alias="bitRate")
    sample_rate: int | None = Field(default=None, validation_alias="sampleRate")
    size: int
    length: int | None = None


class SearchResult(BaseModel):
    file_count: int = Field(validation_alias="fileCount")
    files: list[File]
    has_free_upload_slot: bool = Field(validation_alias="hasFreeUploadSlot")
    locked_file_count: int = Field(validation_alias="lockedFileCount")
    queue_length: int = Field(validation_alias="queueLength")
    upload_speed: int = Field(validation_alias="uploadSpeed")
    username: str


class SearchResponse(BaseModel):
    id: str
    search_text: str = Field(validation_alias="searchText")
    started_at: str = Field(validation_alias="startedAt")
    results: list[SearchResult] = Field(default_factory=list)


class DownloadsFile(BaseModel):
    id: str
    filename: str
    percent_complete: float = Field(validation_alias="percentComplete")
    state: str
    size: int
    exception: str = ""


class DownloadsDirectory(BaseModel):
    directory: str
    file_count: int = Field(validation_alias="fileCount")
    files: list[DownloadsFile]


class DownloadsResponse(BaseModel):
    username: str
    directories: list[DownloadsDirectory]
