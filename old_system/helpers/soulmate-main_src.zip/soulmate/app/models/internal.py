from typing import Literal

from pydantic import BaseModel, Field

from app.models.slskd import File


class SearchTerm(BaseModel):
    text: str
    type: Literal["record", "track"]

    @property
    def key(self) -> str:
        return f"{self.type}--{self.text}"


class MediaInfo(BaseModel):
    audio_file_count: int = 0
    file_type: str = ""
    quality: str = ""
    kbps: int = 0
    vbr: bool = False


class TrackCheck(BaseModel):
    original_title: str
    track_number: str = ""
    possible_titles: list[str] = Field(default_factory=list)


class EstimatedQuality(BaseModel):
    name: str = ""
    weight: int = 0
    preferred_kbps: int = 0


class PotentialRecord(BaseModel):
    username: str
    directory: str
    media_info: MediaInfo = Field(default_factory=MediaInfo)
    slskd_files: list[File] = Field(default_factory=list)
    local_directory: str
    has_free_upload_slot: bool = False
    quality: EstimatedQuality = Field(default_factory=EstimatedQuality)


class DownloadStatus(BaseModel):
    progress: int = 0
    state: str = ""
    retry_possible: bool = False  # if errored states exist, but also success, retry failed files
    removed: bool = False
