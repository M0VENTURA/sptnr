from pydantic import BaseModel


class LinkDownloadRequest(BaseModel):
    record_id: int
    username: str
    directory: str
