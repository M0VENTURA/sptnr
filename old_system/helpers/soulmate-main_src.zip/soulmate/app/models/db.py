from tortoise import fields
from tortoise.models import Model


class DBRecord(Model):
    id = fields.IntField(primary_key=True)
    artist = fields.TextField()
    title = fields.TextField()
    release_date = fields.TextField()
    searched_times = fields.IntField()
    next_search = fields.DatetimeField(db_index=True)
    state = fields.CharField(db_index=True, max_length=32)
    source = fields.CharField(max_length=32)
    created_at = fields.DatetimeField(auto_now_add=True, db_index=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        table = "records"


class DBDownload(Model):
    id = fields.IntField(primary_key=True)
    record_id = fields.IntField(db_index=True)
    username = fields.TextField()
    directory = fields.TextField()
    local_directory = fields.TextField()
    quality = fields.TextField()
    state = fields.CharField(db_index=True, max_length=32)
    progress = fields.IntField(default=0)
    retries = fields.IntField(default=0)
    created_at = fields.DatetimeField(auto_now_add=True, db_index=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        table = "downloads"


class DBBlockedDownload(Model):
    id = fields.IntField(primary_key=True)
    username = fields.CharField(max_length=255, db_index=True)
    directory = fields.CharField(max_length=255, db_index=True)
    created_at = fields.DatetimeField(auto_now_add=True, db_index=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        table = "blocked_downloads"


class DBSearch(Model):
    id = fields.IntField(primary_key=True)
    record_id = fields.IntField(db_index=True)
    completed = fields.BooleanField(db_index=True)
    created_at = fields.DatetimeField(auto_now_add=True, db_index=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        table = "searches"


class DBRecordEvent(Model):
    id = fields.IntField(primary_key=True)
    record_id = fields.IntField(db_index=True)
    event = fields.TextField()
    created_at = fields.DatetimeField(auto_now_add=True, db_index=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        table = "record_events"


class DBSlskdCleanup(Model):
    id = fields.IntField(primary_key=True)
    type = fields.CharField(db_index=True, max_length=32)  # search / download
    identifier = fields.CharField(max_length=255)  # search / download
    created_at = fields.DatetimeField(auto_now_add=True, db_index=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        table = "slskd_cleanup"
