from pydantic import AliasChoices, AliasPath, BaseModel, Field, field_validator


class Artist(BaseModel):
    name: str = Field(validation_alias=AliasChoices("artistName", "name"))
    id: int


class Track(BaseModel):
    absolute_track_number: int = Field(validation_alias=AliasChoices("absolute_track_number", "absoluteTrackNumber"))
    track_number: str = Field(validation_alias=AliasChoices("track_number", "trackNumber"))
    title: str
    duration: int


class RecordRelease(BaseModel):
    id: int
    album_id: int = Field(validation_alias=AliasChoices("album_id", "albumId"))
    track_count: int = Field(validation_alias=AliasChoices("track_count", "trackCount"))
    tracks: list[Track] = Field(default_factory=list)
    status: str = ""
    monitored: bool


class Record(BaseModel):
    id: int
    title: str
    artist: Artist
    album_type: str = Field(validation_alias=AliasChoices("albumType", "album_type"))
    release_date: str = Field(validation_alias=AliasChoices("releaseDate", "release_date"))
    any_release_ok: bool = Field(validation_alias=AliasChoices("anyReleaseOk", "any_release_ok"))
    releases: list[RecordRelease] = []
    quality_profile_id: int = Field(
        validation_alias=AliasChoices(
            "quality_profile_id",
            AliasPath("artist", "qualityProfileId"),
        )
    )
    percent_of_tracks: int = Field(
        validation_alias=AliasChoices(
            "percent_of_tracks",
            AliasPath("statistics", "percentOfTracks"),
        )
    )

    @field_validator("percent_of_tracks", mode="before")
    @classmethod
    def convert_float_to_int(cls, v: int | float) -> int:
        if not v:
            return 0
        return int(v)


class CommandResponse(BaseModel):
    name: str
    id: int
    status: str
    result: str = ""


class QualityConfig(BaseModel):
    name: str = Field(default="", validation_alias=AliasPath("quality", "name"))
    min_size: int = 0
    max_size: int = 0
    preferred_size: int = Field(default=0, validation_alias=AliasChoices("preferredSize", "preferred_size"))
    allowed_file_types: list[str] = []

    @field_validator("min_size", "max_size", "preferred_size", mode="before")
    @classmethod
    def convert_float_to_int(cls, v: int | float) -> int:
        if not v:
            return 0
        return int(v)


class Quality(BaseModel):
    name: str = Field(validation_alias=AliasChoices("name", AliasPath("quality", "name")))
    allowed: bool
    config: QualityConfig = Field(default_factory=QualityConfig)
    weight: int = 0


class QualityGroup(BaseModel):
    name: str
    allowed: bool
    items: list[Quality]
    id: int


class QualityProfile(BaseModel):
    name: str
    upgrade_allowed: bool = Field(validation_alias=AliasChoices("upgrade_allowed", "upgradeAllowed"))
    items: list[Quality | QualityGroup]

    def allowed_quality(self, quality_name: str) -> bool:
        if not quality_name:
            return False

        for item in self.items:
            if isinstance(item, Quality):
                if item.name == quality_name and item.allowed is True:
                    return True
                continue

            for quality in item.items:
                if quality.name == quality_name and item.allowed is True:
                    return True

        return False

    def allowed_quality_upgrade(self, current: str, target: str) -> bool:
        if not all([current, target]):
            return False

        current_found = False
        next_group_id = 0
        for item in self.items:
            if isinstance(item, Quality):
                if item.name == current:
                    current_found = True
                continue

            if current_found:
                next_group_id = item.id
                break

            for quality in item.items:
                if quality.name == current:
                    current_found = True

        cutoff_found = False
        for item in self.items:
            if isinstance(item, Quality):
                if not cutoff_found:
                    continue

                if item.name == target and item.allowed is True:
                    return True
                continue

            if item.id == next_group_id:
                cutoff_found = True

            for quality in item.items:
                if not cutoff_found:
                    continue

                if quality.name == target and item.allowed is True:
                    return True

        return False
