from app.models.db import DBRecord

_TRASH_CHARS = [
    ".",
    "'",
    "\\",
    "〜",
    "[",
    "]",
    "&",
    '"',
    ",",
    "’",  # noqa: RUF001
    "?",
    "!",
    "/",
    "…",
    "′",  # noqa: RUF001
    ":",
    "+",
]


def get_clean_record_name(record: DBRecord) -> str:
    name = f"{record.artist} - {record.title}"
    name = name.replace("/", " ")

    if len(record.release_date) > 4:
        name += f" ({record.release_date[:4]})"

    return name


def clean_search_term(text: str) -> str:
    for t in _TRASH_CHARS:
        text = text.replace(t, " ")

    return " ".join(text.split())
