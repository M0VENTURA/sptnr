import asyncio

import httpx
from tenacity import retry, retry_if_exception_type, stop_after_attempt

from app.constants import SearchTermTypes
from app.models.db import DBSlskdCleanup
from app.models.internal import SearchTerm
from app.models.slskd import SearchResponse, SearchResult
from app.slskd.api import (
    slskd_api_delete_search,
    slskd_api_get_search_responses,
    slskd_api_get_search_state,
    slskd_api_perform_search,
)


async def search_slskd(search_term: SearchTerm) -> SearchResponse:
    timeout = 20 if search_term.type == SearchTermTypes.record else 5

    raw_result = await slskd_api_perform_search(
        search_term.text,
        timeout=timeout * 1000,
    )

    response = SearchResponse.model_validate(raw_result)
    await DBSlskdCleanup(type="search", identifier=response.id).save()

    for _ in range(30):
        raw_result = await slskd_api_get_search_state(response.id)
        if raw_result["state"] != "InProgress":
            break
        await asyncio.sleep(1)

    raw = await slskd_api_get_search_responses(response.id)

    response.results = [SearchResult.model_validate(o) for o in raw]

    return response


@retry(retry=retry_if_exception_type(httpx.HTTPStatusError), stop=stop_after_attempt(3), reraise=True)
async def delete_search(search_id: str) -> None:
    try:
        await slskd_api_delete_search(search_id)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return
        raise
