import httpx
from tenacity import retry, retry_if_exception_type, stop_after_attempt

from app.models.slskd import File
from app.slskd.api import slskd_api_get_user_directory


@retry(retry=retry_if_exception_type(httpx.HTTPStatusError), stop=stop_after_attempt(3), reraise=True)
async def get_user_directory_contents(username: str, directory: str) -> list[File]:
    response = await slskd_api_get_user_directory(
        username=username,
        directory=directory,
    )

    results = []
    for item in response:
        results += [File.model_validate(o) for o in item["files"]]

    return results
