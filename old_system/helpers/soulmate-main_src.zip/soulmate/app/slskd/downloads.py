import httpx
from tenacity import retry, retry_if_exception_type, stop_after_attempt

from app.constants import DownloadStates
from app.media import should_download_file
from app.models.internal import DownloadStatus, PotentialRecord
from app.models.slskd import DownloadsResponse
from app.slskd.api import (
    slskd_api_cancel_download,
    slskd_api_enqueue_files,
    slskd_api_get_downloads_by_username,
    slskd_api_get_user_directory,
)


async def download_potential_result(potential: PotentialRecord) -> bool:
    try:
        response = await slskd_api_get_user_directory(potential.username, potential.directory)

        files = []
        for entry in response:
            directory = entry["name"]

            for o in entry["files"]:
                if await should_download_file(o["filename"]) is False:
                    continue

                files.append(
                    {
                        "filename": f"{directory}\\{o['filename']}",
                        "size": o["size"],
                    }
                )

                # in order not to get stuck on gigantic payloads, we split the enqueue operation into smaller parts
                if files and len(files) % 20 == 0:
                    await slskd_api_enqueue_files(potential.username, files)
                    files = []

        # enqueue last 1-19 files if applicable
        if files:
            await slskd_api_enqueue_files(potential.username, files)

        return True
    except httpx.HTTPError:
        return False


@retry(retry=retry_if_exception_type(httpx.HTTPError), stop=stop_after_attempt(3), reraise=True)
async def get_username_downloads(username: str) -> DownloadsResponse:
    response = await slskd_api_get_downloads_by_username(username)

    return DownloadsResponse.model_validate(response)


@retry(retry=retry_if_exception_type(httpx.HTTPError), stop=stop_after_attempt(3), reraise=True)
async def get_slskd_download_status(username: str, directory: str) -> DownloadStatus:
    total_progress = 0
    files = 0

    state = DownloadStates.downloading
    try:
        downloads = await get_username_downloads(username)

        directory_found = False

        for download in downloads.directories:
            retry_possible = False
            if download.directory != directory:
                continue
            directory_found = True
            for download_file in download.files:
                total_progress += download_file.percent_complete
                files += 1

                if any(x in download_file.state for x in ("Errored", "Cancelled")):
                    state = DownloadStates.error

                if "Succeeded" in download_file.state:
                    retry_possible = True

        if not directory_found:
            return DownloadStatus(
                state=DownloadStates.error,
                progress=0,
                retry_possible=False,
                removed=True,
            )

        progress = int(total_progress / files) if files else 0
        if progress == 100:
            state = DownloadStates.success

        status = DownloadStatus(
            state=state,
            progress=progress,
            retry_possible=retry_possible,
        )
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return DownloadStatus(
                state=DownloadStates.error,
                progress=0,
                retry_possible=False,
                removed=True,
            )
        raise

    return status


@retry(retry=retry_if_exception_type(httpx.HTTPError), stop=stop_after_attempt(3), reraise=True)
async def retry_slskd_download(username: str, directory: str) -> None:
    downloads = await get_username_downloads(username)

    for download in downloads.directories:
        if download.directory != directory:
            continue

        errored = []
        for file_object in download.files:
            if "Errored" in file_object.state:
                errored.append(
                    {
                        "filename": file_object.filename,
                        "size": file_object.size,
                    }
                )

            if errored and len(errored) % 20 == 0:
                await slskd_api_enqueue_files(username, errored)
                errored = []

        if errored:
            await slskd_api_enqueue_files(username, errored)


@retry(retry=retry_if_exception_type(httpx.HTTPError), stop=stop_after_attempt(3), reraise=True)
async def delete_slskd_download(username: str, directory: str) -> bool:
    """
    This uses the cancel download endpoint, but works for successful downloads as well
    """
    try:
        response = await slskd_api_get_downloads_by_username(username)

        ids_to_delete = set()

        downloads = DownloadsResponse.model_validate(response)

        for download in downloads.directories:
            if download.directory != directory:
                continue

            for download_file in download.files:
                cancel = "Queued" in download_file.state
                ids_to_delete.add((cancel, download_file.id))

        for cancel, download_id in ids_to_delete:
            # need to first cancel due to reasons
            if cancel:
                await slskd_api_cancel_download(username=username, download_id=download_id)

            await slskd_api_cancel_download(username=username, download_id=download_id, remove=True)

        return True

    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return True
        raise
