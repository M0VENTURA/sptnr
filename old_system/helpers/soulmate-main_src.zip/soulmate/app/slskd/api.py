import functools
import uuid
from typing import TypedDict
from urllib.parse import quote

import httpx

from app.config import settings


@functools.cache
def _get_slskd_client() -> httpx.AsyncClient:
    return httpx.AsyncClient(timeout=httpx.Timeout(20))


@functools.cache
def _get_slskd_headers() -> dict[str, str]:
    return {
        "X-API-Key": settings.slskd.key,
        "Content-Type": "application/json",
    }


@functools.cache
def _slskd_api_url() -> str:
    return settings.slskd.url.strip("/") + "/api/v0"


DownloadFile = TypedDict(
    "DownloadFile",
    {
        "filename": str,
        "size": int,
    },
)


async def slskd_api_enqueue_files(username: str, downloads: list[DownloadFile]) -> None:
    client = _get_slskd_client()
    response = await client.post(
        f"{_slskd_api_url()}/transfers/downloads/{quote(username)}",
        json=downloads,
        headers=_get_slskd_headers(),
    )

    response.raise_for_status()


async def slskd_api_get_user_directory(username: str, directory: str) -> dict:
    client = _get_slskd_client()

    response = await client.post(
        f"{_slskd_api_url()}/users/{quote(username)}/directory",
        json={
            "directory": directory,
        },
        headers=_get_slskd_headers(),
    )
    response.raise_for_status()

    return response.json()


async def slskd_api_get_downloads_by_username(username: str) -> dict:
    client = _get_slskd_client()

    response = await client.get(
        f"{_slskd_api_url()}/transfers/downloads/{quote(username)}",
        headers=_get_slskd_headers(),
    )
    response.raise_for_status()

    return response.json()


async def slskd_api_cancel_download(username: str, download_id: str, remove: bool = False) -> None:
    client = _get_slskd_client()

    response = await client.delete(
        f"{_slskd_api_url()}/transfers/downloads/{quote(username)}/{download_id}",
        headers=_get_slskd_headers(),
        params={"remove": "true"} if remove is True else None,
    )
    response.raise_for_status()


async def slskd_api_perform_search(search_text: str, timeout: int = 15000) -> dict:
    client = _get_slskd_client()

    data = {
        "id": str(uuid.uuid1()),
        "fileLimit": 10000,
        "filterResponses": True,
        "maximumPeerQueueLength": 1000000,
        "minimumPeerUploadSpeed": 0,
        "minimumResponseFileCount": 1,
        "responseLimit": 100,
        "searchText": search_text,
        "searchTimeout": timeout,
    }

    response = await client.post(
        f"{_slskd_api_url()}/searches",
        headers=_get_slskd_headers(),
        json=data,
    )

    response.raise_for_status()

    return response.json()


async def slskd_api_get_search_state(search_id: str) -> dict:
    client = _get_slskd_client()

    response = await client.get(
        f"{_slskd_api_url()}/searches/{search_id}",
        headers=_get_slskd_headers(),
    )
    response.raise_for_status()

    return response.json()


async def slskd_api_get_search_responses(search_id: str) -> list:
    client = _get_slskd_client()

    response = await client.get(
        f"{_slskd_api_url()}/searches/{search_id}/responses",
        headers=_get_slskd_headers(),
    )
    response.raise_for_status()

    return response.json()


async def slskd_api_delete_search(search_id: str) -> None:
    client = _get_slskd_client()

    response = await client.delete(
        f"{_slskd_api_url()}/searches/{search_id}",
        headers=_get_slskd_headers(),
    )
    response.raise_for_status()


async def slskd_api_get_connection_status() -> dict:
    client = _get_slskd_client()

    response = await client.get(
        f"{_slskd_api_url()}/server",
        headers=_get_slskd_headers(),
    )
    response.raise_for_status()

    return response.json()
