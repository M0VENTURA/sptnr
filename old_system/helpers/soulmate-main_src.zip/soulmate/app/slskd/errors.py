_UNSEARCHABLE_TERMS = [
    "bryan",
    "adams",
    "best coast",
    "enter shikari",
    "beatles",
    "village people",
    "lenny kravitz",
    "chicane saltwater",
    "beyonce",
    "xxx",
    "fox on the box",
    "franz ferdinand",
]


def has_unsearchable_terms(text: str) -> bool:
    if not any(len(x) > 1 for x in text.split()):
        return True

    return any(term in text.casefold() for term in _UNSEARCHABLE_TERMS)
