from tortoise.exceptions import DoesNotExist, MultipleObjectsReturned

from app.models.db import DBBlockedDownload


async def block_download(username: str, directory: str) -> None:
    try:
        await DBBlockedDownload.get(username=username, directory="*")
        user_blocked = True
    except DoesNotExist:
        user_blocked = False
    except MultipleObjectsReturned:
        user_blocked = True

    if user_blocked:
        # user already blocked, no reason to store anything
        return

    try:
        await DBBlockedDownload.get(username=username, directory=directory)
    except DoesNotExist:
        await DBBlockedDownload(username=username, directory=directory).save()
    except MultipleObjectsReturned:
        pass
