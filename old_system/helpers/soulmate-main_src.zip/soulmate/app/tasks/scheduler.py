import asyncio
from datetime import datetime, timedelta

import structlog
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from app.config import settings
from app.log import get_soulmate_logger
from app.tasks.cleanup import perform_database_cleanup, perform_slskd_cleanup
from app.tasks.downloads import move_completed_downloads, update_download_states
from app.tasks.imports import lidarr_import_records
from app.tasks.searches import search_and_download_records
from app.tasks.wanted import update_lidarr_wanted_records

scheduler = AsyncIOScheduler()


@scheduler.scheduled_job(
    "interval",
    minutes=3,
    next_run_time=datetime.now(),
    misfire_grace_time=30,
)
async def task_update_lidarr_wanted_records() -> None:
    try:
        await update_lidarr_wanted_records()
    except Exception as e:
        structlog.get_logger("soulmate.error").exception(e, task="task_update_lidarr_wanted_records")


@scheduler.scheduled_job(
    "interval",
    minutes=6,
    next_run_time=datetime.now() + timedelta(seconds=20),
    misfire_grace_time=30,
)
async def task_search_and_download_records() -> None:
    if not settings.slskd.enabled:
        return

    try:
        # we do a timeout in case the logic gets stuck for some reason
        async with asyncio.timeout(timedelta(hours=1).total_seconds()):
            await search_and_download_records()
    except asyncio.TimeoutError:
        get_soulmate_logger().warning("timout reached on search")

    except Exception as e:
        structlog.get_logger("soulmate.error").exception(e, task="task_search_and_download_records")


@scheduler.scheduled_job(
    "interval",
    minutes=5,
    next_run_time=datetime.now() + timedelta(seconds=30),
    misfire_grace_time=30,
)
async def task_update_download_states() -> None:
    try:
        await update_download_states()
    except Exception as e:
        structlog.get_logger("soulmate.error").exception(e, task="task_update_download_states")


@scheduler.scheduled_job(
    "interval",
    minutes=5,
    next_run_time=datetime.now() + timedelta(seconds=60),
    misfire_grace_time=30,
)
async def task_move_completed_downloads() -> None:
    try:
        await move_completed_downloads()
    except Exception as e:
        structlog.get_logger("soulmate.error").exception(e, task="task_move_completed_downloads")


@scheduler.scheduled_job(
    "interval",
    minutes=5,
    next_run_time=datetime.now() + timedelta(seconds=90),
    misfire_grace_time=30,
)
async def task_lidarr_import_records() -> None:
    try:
        if not settings.automatic_lidarr_import:
            return

        await lidarr_import_records()
    except Exception as e:
        structlog.get_logger("soulmate.error").exception(e, task="task_lidarr_import_records")


@scheduler.scheduled_job(
    "interval",
    minutes=5,
    misfire_grace_time=30,
    next_run_time=datetime.now() + timedelta(seconds=30),
)
async def task_cleanup_database() -> None:
    try:
        await perform_database_cleanup()
    except Exception as e:
        structlog.get_logger("soulmate.error").exception(e, task="task_cleanup_database")


@scheduler.scheduled_job(
    "interval",
    minutes=6,
    misfire_grace_time=30,
    next_run_time=datetime.now() + timedelta(seconds=30),
)
async def task_cleanup_slskd() -> None:
    try:
        await perform_slskd_cleanup()
    except Exception as e:
        structlog.get_logger("soulmate.error").exception(e, task="task_cleanup_slskd")
