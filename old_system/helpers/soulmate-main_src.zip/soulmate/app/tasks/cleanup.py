import os
import shutil
from datetime import UTC, datetime, timedelta

import httpx
from tortoise.exceptions import DoesNotExist

from app.config import settings
from app.constants import DownloadStates, Events, RecordStates
from app.lidarr.queue import in_queue
from app.lidarr.wanted import get_wanted
from app.models.db import DBDownload, DBRecord, DBRecordEvent, DBSearch, DBSlskdCleanup
from app.slskd.downloads import delete_slskd_download
from app.slskd.searches import delete_search


async def _purge_record(record: DBRecord) -> None:
    # delete all download entries
    downloads = await DBDownload.filter(record_id=record.id)
    for download in downloads:
        await download.delete()

    # delete all search entries
    searches = await DBSearch.filter(record_id=record.id)
    for search in searches:
        await search.delete()

    # delete all record events
    events = await DBRecordEvent.filter(record_id=record.id)
    for event in events:
        await event.delete()

    # finally, delete the record
    await record.delete()


async def perform_database_cleanup() -> None:
    old_db_records = await DBRecord.all()
    record_ids = set()
    records = set()
    if settings.search_missing:
        for missing in await get_wanted():
            records.add(missing.id)

    if settings.search_unmet:
        for unmet in await get_wanted(missing=False):
            records.add(unmet.id)

    for old_db_record in old_db_records:
        record_ids.add(old_db_record.id)
        if old_db_record.state == RecordStates.manual and settings.require_manual_imports:
            # might not have had the time to show up in the queue yet
            if datetime.now(UTC) - old_db_record.updated_at < timedelta(minutes=1):
                continue

            if await in_queue(old_db_record.id):
                continue

            still_wanted = old_db_record.id in records
            old_db_record.state = RecordStates.wanted if still_wanted else RecordStates.removed

            await old_db_record.save()

            if still_wanted is False:
                await DBRecordEvent(record_id=old_db_record.id, event=Events.removed).save()

        if old_db_record.id in records:
            continue

        if datetime.now(UTC) - old_db_record.updated_at > timedelta(hours=48):
            await _purge_record(old_db_record)

    # there are some edge cases where a download can get stuck in downloading
    for download in await DBDownload.filter(state=DownloadStates.downloading):
        try:
            record = await DBRecord.get(id=download.record_id)
        except DoesNotExist:
            await download.delete()
            continue

        if record.state not in (RecordStates.downloading, RecordStates.downloaded):
            download.state = DownloadStates.error
            await download.save()

    for db_event in await DBRecordEvent.all():
        if db_event.record_id in record_ids:
            continue

        # if any events are orphaned, just remove them
        await db_event.delete()

    for search in await DBSearch.all():
        if search.record_id in record_ids:
            continue

        # if any searches are orphaned, just remove them
        await search.delete()


async def perform_slskd_cleanup() -> None:
    searches = await DBSlskdCleanup.filter(type="search")
    for search in searches:
        if not datetime.now(UTC) > search.updated_at + timedelta(minutes=3):
            continue
        try:
            await delete_search(search.identifier)
            await search.delete()
        except httpx.HTTPError:
            continue

    downloads = await DBSlskdCleanup.filter(type="download")
    ongoing_downloads = await DBDownload.filter(state__in=(DownloadStates.downloading, DownloadStates.success))
    for download in downloads:
        username, directory = download.identifier.split("###", 1)

        # download is correctly monitored and ongoing, ignore it for now
        if any(x.username == username and x.directory == directory for x in ongoing_downloads):
            continue

        try:
            if not await delete_slskd_download(username=username, directory=directory):
                continue

            local_directory = directory.rsplit("\\", 1)[-1]
            download_path = settings.slskd.download_path / local_directory
            if os.path.isdir(download_path):
                if settings.delete_errored_downloads:
                    shutil.rmtree(download_path)
                else:
                    error_path = settings.slskd.download_path / "soulmate" / "errors"
                    shutil.move(download_path, error_path / local_directory)

            await download.delete()

        except httpx.HTTPError:
            continue
