import contextlib
from datetime import UTC, datetime, timedelta
from typing import Generator

import httpx
from rapidfuzz import fuzz
from tortoise.exceptions import DoesNotExist

from app.adapters.match import match_potential_release
from app.adapters.quality import get_quality
from app.adapters.search import get_potential_records
from app.config import settings
from app.constants import DownloadStates, Events, RecordStates, SearchTermTypes
from app.exceptions import MaxConcurrentDownloadsReachedError
from app.format import clean_search_term
from app.lidarr.quality import get_current_record_quality, get_quality_profile
from app.lidarr.record import get_record
from app.log import get_soulmate_logger
from app.media import supported_media_file
from app.models.db import DBBlockedDownload, DBDownload, DBRecord, DBRecordEvent, DBSearch, DBSlskdCleanup
from app.models.internal import PotentialRecord, SearchTerm
from app.models.lidarr import Record
from app.models.slskd import File
from app.slskd.downloads import download_potential_result
from app.slskd.errors import has_unsearchable_terms
from app.slskd.searches import delete_search, search_slskd
from app.slskd.user import get_user_directory_contents
from app.tasks.shared import block_download


def _search_possibilities(record: Record) -> Generator[SearchTerm, None, None]:
    # single track releases (mainly singles, but we dont discriminate) gives off weird results sometimes
    # by enforcing track search we ensure that the entire directory contents are compared to the release
    record_search_term = (
        SearchTermTypes.track if any(x.track_count == 1 for x in record.releases) else SearchTermTypes.record
    )

    for suffix in settings.additional_searches:
        yield SearchTerm(text=clean_search_term(f"{record.title} {suffix}"), type=record_search_term)

    self_titled = record.artist.name == record.title
    if not self_titled:
        yield SearchTerm(text=f"{record.artist.name} {record.title}", type=record_search_term)

    yield SearchTerm(text=clean_search_term(f"{record.title} {record.release_date[:4]}"), type=record_search_term)
    yield SearchTerm(text=clean_search_term(f"{record.title}"), type=record_search_term)
    yield SearchTerm(text=clean_search_term(record.title), type=record_search_term)

    for delimiter in ("(", ":"):
        if delimiter not in record.title:
            continue

        simple_title = record.title.split(delimiter)[0].strip()
        if not self_titled:
            yield SearchTerm(text=f"{record.artist.name} {simple_title}", type=record_search_term)

        yield SearchTerm(text=clean_search_term(simple_title), type=record_search_term)

    track_titles = set()
    for release in record.releases:
        # skip non-official releases for track searches
        if release.status != "Official":
            continue

        for track in release.tracks:
            track_titles.add(track.title.casefold())

    # search for longest titles first, as they are more likely to be unique and find a hit
    for title in sorted(list(track_titles), key=lambda x: len(x), reverse=True):
        # already searched for
        if clean_search_term(title) == clean_search_term(record.title):
            continue

        yield SearchTerm(text=clean_search_term(title), type=SearchTermTypes.track)


def _partial_ratio_check(full_string: str, partial_string: str) -> float:
    return fuzz.partial_ratio(full_string.casefold(), partial_string.casefold())


def _get_audio_file_count(files: list[File]) -> int:
    total = 0
    for f in files:
        if supported_media_file(f.filename):
            total += 1

    return total


async def _matches_from_search(
    record: Record,
    search_term: SearchTerm,
    ordered_results: list[PotentialRecord],
    checked_directories: set[str],
) -> list[PotentialRecord]:
    matches = []

    for potential in ordered_results:
        if search_term.type == SearchTermTypes.track:
            # since these are many, we are trying to make sure that there is at leas a semblance of a chance that it's a correct hit
            record_score = _partial_ratio_check(potential.directory, record.title)
            artist_score = _partial_ratio_check(potential.directory, record.artist.name)

            if record_score < 70 and artist_score < 70:
                # it's probably not this
                continue

            # if we searched for a track we need to get the file-list from the user to get the entire directory contents
            try:
                dir_key = f"{potential.username}--{potential.directory}"
                if dir_key in checked_directories:
                    # not a check for the current record, so we can skip fetching directory contents again
                    continue

                potential.slskd_files = await get_user_directory_contents(
                    potential.username,
                    potential.directory,
                )
                potential.media_info.audio_file_count = _get_audio_file_count(potential.slskd_files)
                checked_directories.add(dir_key)
            except httpx.HTTPStatusError:
                continue

        matched_release_id = match_potential_release(record, potential)
        if matched_release_id:
            matches.append(potential)

    return matches


def _match_sorter(potential: PotentialRecord) -> str:
    """
    max weight is currently hard coded to 38 (different qualities) in lidarr, so we do some weird looking math in order to make sense of it

    best possible match has the correct preffered kbps, so we also try to get it as close to 0 as possible for sorting

    finally we want to try free upload slots first

    then use weight first, and then proximity to preffered kbps in order to get sorting the way we want
    this should end up with all wav matches being sorted first into the the results, and internally ordered by proximity to preffered
    """
    weight_number = 500 - potential.quality.weight * 10  # current lowest possible number is 120

    # slightly nudge weight down a bit if no download slots are available
    # this would make it 121 for WAV if no upload slot, while free slot WAV (assusming it's highest in the list) potentials have 120
    # the first lossless would have 130
    if potential.has_free_upload_slot is False:
        weight_number += 1

    weight = str(weight_number).zfill(5)
    preferred_proximity = str(abs(potential.media_info.kbps - potential.quality.preferred_kbps)).zfill(10)

    return f"{weight}--{preferred_proximity}"


async def _search_and_download_record(record_id: int) -> None:
    logger = get_soulmate_logger()

    try:
        db_record = await DBRecord.get(id=record_id)
        log_data = {
            "record_artist": db_record.artist,
            "record_title": db_record.title,
        }
        # if already downloading or downloaded, skip searching
        if db_record.state in (RecordStates.downloading, RecordStates.downloaded):
            logger.info(
                "download already in progress",
                **log_data,
            )
            return

    except DoesNotExist:
        # record has been removed while still in queue, no need to do anything
        return

    # check concurrent downloads not to overburden slskd
    downloads = await DBDownload.filter(state=DownloadStates.downloading)
    if len(downloads) >= settings.max_concurrent_downloads:
        raise MaxConcurrentDownloadsReachedError()

    # TODO: is this really needed? APScheduler probably makes it superflous
    try:
        db_search = await DBSearch.get(record_id=record_id, completed=False)
        # record already has an unfinished search, but if its too old we want to remove it
        if datetime.now(tz=UTC) - db_search.created_at > timedelta(minutes=12):
            db_search.completed = True
            await db_search.save()
        return

    except DoesNotExist:
        db_search = DBSearch(record_id=record_id, completed=False)
        await db_search.save()
        await DBRecordEvent(record_id=record_id, event=Events.search_performed).save()

    record = await get_record(record_id)
    quality_profile = await get_quality_profile(record.quality_profile_id)

    current_quality = await get_current_record_quality(record_id) if db_record.source == "unmet" else []

    blocked_downloads = set([f"{x.username}--{x.directory}" for x in await DBBlockedDownload.all()])
    checked_directories = set()

    search_start = datetime.now(UTC)
    log_copy = "search finished, no match found"
    log_data = {
        "record_artist": record.artist.name,
        "record_title": record.title,
    }
    already_performed = set()
    search_response = None
    try:
        for search_term in _search_possibilities(record):
            # some terms are unsearchable, so let's just skip those searches entirely
            if has_unsearchable_terms(search_term.text):
                continue

            if search_term.key in already_performed:
                continue

            try:
                search_response = await search_slskd(search_term)

                ordered_results = get_potential_records(search_response.results)

                # get all the matches from the search
                # this allows us to choose the best match rather than just take the first one
                # it should not matter much for record searches, but might slow down track searches considerably
                matches = await _matches_from_search(record, search_term, ordered_results, checked_directories)
                pruned_matches: list[PotentialRecord] = []

                for match in matches:
                    blocked_checks = [f"{match.username}--*", f"{match.username}--{match.directory}"]
                    if any(x in blocked_downloads for x in blocked_checks):
                        continue

                    quality = get_quality(quality_profile, match)

                    if not quality:
                        continue

                    match.quality.name = quality.name
                    match.quality.weight = quality.weight
                    match.quality.preferred_kbps = quality.config.preferred_size

                    if quality_profile.allowed_quality(quality.name) is False:
                        continue

                    if any(
                        quality_profile.allowed_quality_upgrade(x, match.quality.name) is False for x in current_quality
                    ):
                        continue

                    pruned_matches.append(match)

                for match in sorted(pruned_matches, key=lambda x: _match_sorter(x)):
                    download_cleanup = DBSlskdCleanup(
                        type="download", identifier=f"{match.username}###{match.directory}"
                    )
                    await download_cleanup.save()

                    try:
                        success = await download_potential_result(match)
                    except httpx.HTTPError:
                        success = False

                    if success:
                        log_copy = "successfully added download"
                        log_data["inferred_quality"] = match.quality.name
                        await DBDownload(
                            record_id=record.id,
                            username=match.username,
                            directory=match.directory,
                            local_directory=match.local_directory,
                            state=DownloadStates.downloading,
                            quality=match.quality.name,
                        ).save()
                        db_record.state = "downloading"
                        await db_record.save()
                        await DBRecordEvent(record_id=record.id, event=Events.download_added).save()
                        return

                    else:
                        logger.info(
                            "failed to add download",
                            **log_data,
                            search_type=search_term.type,
                        )
                        await DBDownload(
                            record_id=record.id,
                            username=match.username,
                            directory=match.directory,
                            local_directory=match.local_directory,
                            state=DownloadStates.error,
                            quality=match.quality.name,
                        ).save()
                        await block_download(username=match.username, directory="*")
                        for check in blocked_checks:
                            blocked_downloads.add(check)

            finally:
                # always detele the search in slskd
                if search_response:
                    # try deleting the search, but if it fails, just let the cleanup handle it later
                    with contextlib.suppress(httpx.HTTPError):
                        await delete_search(search_response.id)

                already_performed.add(search_term.key)

    finally:
        # always mark the search as completed
        db_search.completed = True
        await db_search.save()

        # always add more search time to the record, in case the download or import fails
        db_record.searched_times += 1
        next_search = datetime.now(UTC) + timedelta(minutes=30 * min(db_record.searched_times, 20))
        db_record.next_search = next_search
        await db_record.save()
        logger.info(
            log_copy,
            **log_data,
            time=str(datetime.now(UTC) - search_start),
        )


async def search_and_download_records() -> None:
    records = await DBRecord.filter(state=RecordStates.wanted, next_search__lte=datetime.now(UTC))

    task_start = datetime.now(UTC)
    try:
        for record in sorted(records, key=lambda x: f"{x.source} {x.next_search}"):
            await _search_and_download_record(record.id)

            # stop the current search task if it runs too long
            if datetime.now(UTC) - task_start > timedelta(minutes=30):
                return

    except MaxConcurrentDownloadsReachedError:
        return
