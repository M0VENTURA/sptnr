from datetime import UTC, datetime, timedelta

from tortoise.exceptions import IntegrityError

from app.config import settings
from app.constants import Events, RecordStates
from app.lidarr.wanted import get_wanted
from app.models.db import DBRecord, DBRecordEvent
from app.models.lidarr import Record


async def update_lidarr_wanted_records() -> None:
    missing: list[Record] = []
    unmet: list[Record] = []
    if settings.search_missing:
        missing += await get_wanted()
    if settings.search_unmet:
        unmet += await get_wanted(missing=False)

    old_db_records = {x.id: x for x in await DBRecord.all()}

    for records, source in [(missing, "missing"), (unmet, "unmet")]:
        for record in records:
            if record.album_type in settings.ignored_lidarr_album_types:
                continue

            old_db_record = old_db_records.pop(record.id) if record.id in old_db_records else None

            if old_db_record:
                old_source = old_db_record.source
                updated_info = {
                    "artist": record.artist.name,
                    "title": record.title,
                    "release_date": record.release_date,
                    "source": source,
                }
                if old_db_record.state not in (
                    RecordStates.downloading,
                    RecordStates.downloaded,
                    RecordStates.manual,
                    RecordStates.wanted,
                ):
                    updated_info["state"] = RecordStates.wanted

                old_db_record.update_from_dict(updated_info)
                await old_db_record.save()

                # if previously imported, add as unmet
                if "state" in updated_info or source != old_source:
                    await DBRecordEvent(record_id=record.id, event=Events.wanted_unmet).save()

            else:
                db_record = DBRecord(
                    id=record.id,
                    artist=record.artist.name,
                    title=record.title,
                    release_date=record.release_date,
                    searched_times=0,
                    source=source,
                    next_search=(datetime.now(UTC) + timedelta(minutes=settings.initial_wait_minutes)),
                    state=RecordStates.wanted,
                )
                try:
                    await db_record.save()
                except IntegrityError:
                    if any(x.id == record.id for x in missing) and any(x.id == record.id for x in unmet):
                        # record is both in missing and in unmet, this can happen if you have only a partial record
                        continue
                    raise

                event = Events.wanted_missing if source == "missing" else Events.wanted_unmet
                await DBRecordEvent(
                    record_id=record.id,
                    event=event,
                ).save()

    for old_db_record in old_db_records.values():
        # wanted state is shoe in for removal if not wanted by lidarr
        # if the record is removed while in manual state, we can assume that it was imported
        if old_db_record.state not in (RecordStates.wanted, RecordStates.manual):
            continue

        old_db_record.state = RecordStates.removed
        await old_db_record.save()

        await DBRecordEvent(
            record_id=old_db_record.id,
            event=Events.removed,
        ).save()
