import os
import shutil
from datetime import UTC, datetime, timedelta

import httpx

from app.config import settings
from app.constants import DownloadStates, Events, RecordStates
from app.format import get_clean_record_name
from app.log import get_soulmate_logger
from app.models.db import DBDownload, DBRecord, DBRecordEvent
from app.slskd.downloads import delete_slskd_download, get_slskd_download_status, retry_slskd_download
from app.tasks.shared import block_download


async def _update_download_state(record_id: int) -> None:
    logger = get_soulmate_logger()
    downloads = await DBDownload.filter(record_id=record_id, state=DownloadStates.downloading)
    record = await DBRecord.get(id=record_id)

    if not downloads and record.state == RecordStates.downloading:
        record.state = RecordStates.wanted
        await record.save()
        return

    for download in downloads:
        new_record_state = ""
        new_download_state = ""
        event = ""
        deletion_handling = False

        try:
            status = await get_slskd_download_status(download.username, download.directory)
        except httpx.HTTPStatusError:
            logger.error(
                "slskd api error: update download state",
                username=download.username,
                directory=download.directory,
            )
            continue

        if status.progress > download.progress:
            download.progress = status.progress
            await download.save()

        if status.state == DownloadStates.success:
            new_record_state = RecordStates.downloaded
            new_download_state = DownloadStates.success
            event = Events.download_success

        # updated_at is updated when progress is increased, so we check stalled time towards it
        elif datetime.now(tz=UTC) - download.updated_at > timedelta(minutes=settings.stalled_download_minutes):
            if any(d.id != download.id and d.username == download.username for d in downloads):
                # user has another download in progress, so this one should not count as stalled yet
                continue

            new_record_state = RecordStates.wanted
            new_download_state = DownloadStates.stalled
            deletion_handling = True
            event = Events.download_stalled

        elif status.state == DownloadStates.error:
            if status.retry_possible is True and download.retries < 5:
                try:
                    await retry_slskd_download(download.username, download.directory)
                    download.retries += 1
                    await download.save()
                except httpx.HTTPStatusError:
                    continue

            else:
                new_record_state = RecordStates.wanted
                new_download_state = DownloadStates.error
                deletion_handling = True
                event = Events.download_error

        if deletion_handling:
            try:
                await delete_slskd_download(download.username, download.directory)
            except httpx.HTTPStatusError:
                logger.error(
                    "slskd api error: delete download",
                    username=download.username,
                    directory=download.directory,
                )

            await block_download(username=download.username, directory="*")

            if settings.delete_errored_downloads:
                _delete_download_files(download)
            else:
                _move_error_download(record, download)

        if new_record_state:
            record.state = new_record_state
            await record.save()

        if new_download_state:
            download.state = new_download_state
            await download.save()

        if event:
            await DBRecordEvent(record_id=record_id, event=event).save()


async def update_download_states() -> None:
    records = await DBRecord.filter(state=RecordStates.downloading)
    for record in records:
        await _update_download_state(record.id)


async def _move_completed_download(record: DBRecord, download: DBDownload) -> bool:
    logger = get_soulmate_logger()

    if download.state != DownloadStates.success:
        logger.info(
            "invalid download state",
            download_state=download.state,
            directory=download.local_directory,
            artist_name=record.artist,
            record_title=record.title,
        )
        # should be moved elsewhere maybe
        return False

    if not settings.slskd.download_path.exists():
        logger.warning("seems like the specified slskd download path does not exist")
        return False

    if os.path.isdir(settings.slskd.download_path / download.directory):
        download.local_directory = download.directory

    if not os.path.isdir(settings.slskd.download_path / download.local_directory):
        # already moved
        logger.info(
            "directory does not exist",
            download_state=download.state,
            directory=download.local_directory,
            artist_name=record.artist,
            record_title=record.title,
        )
        return False

    import_dir = settings.slskd.download_path / "soulmate" / "imports"
    os.makedirs(import_dir, exist_ok=True)

    renamed_directory = get_clean_record_name(record)
    if download.quality:
        renamed_directory += f" [{download.quality}]"

    if os.path.isdir(import_dir / renamed_directory):
        renamed_directory += f" - id.{download.id}"

    shutil.move(settings.slskd.download_path / download.local_directory, import_dir / renamed_directory)

    download.state = DownloadStates.moved
    download.local_directory = renamed_directory
    await download.save()

    return True


def _delete_download_files(download: DBDownload) -> None:
    for path in [
        settings.slskd.download_path / download.local_directory,
        settings.slskd.download_path / "soulmate" / "errors" / download.local_directory,
        settings.slskd.download_path / "soulmate" / "failed" / download.local_directory,
        settings.slskd.download_path / "soulmate" / "imports" / download.local_directory,
    ]:
        if not os.path.isdir(path):
            return

        shutil.rmtree(path)


async def move_completed_downloads() -> None:
    records = await DBRecord.filter(state=RecordStates.downloaded)

    for record in records:
        downloads = await DBDownload.filter(
            record_id=record.id,
            state=DownloadStates.success,
        )

        for download in downloads:
            success = await _move_completed_download(record, download)
            if not success:
                download.state = DownloadStates.error
                await download.save()

                record.state = RecordStates.wanted
                await record.save()


def _move_error_download(record: DBRecord, download: DBDownload) -> None:
    if not os.path.isdir(settings.slskd.download_path / download.local_directory):
        # nothing downloaded to move
        return

    if not settings.slskd.download_path.exists():
        get_soulmate_logger().warning("seems like the specified slskd download path does not exist")
        return

    import_dir = settings.slskd.download_path / "soulmate" / "errors"
    os.makedirs(import_dir, exist_ok=True)

    renamed_directory = get_clean_record_name(record)
    if download.quality:
        renamed_directory += f" [{download.quality}]"

    if os.path.isdir(import_dir / renamed_directory):
        renamed_directory += f" - id.{download.id}"

    shutil.move(settings.slskd.download_path / download.local_directory, import_dir / renamed_directory)
