import asyncio
import os
import shutil

import httpx

from app.config import settings
from app.constants import DownloadStates, Events, RecordStates
from app.lidarr.api import lidarr_api_get_import, lidarr_api_import_record
from app.log import get_soulmate_logger
from app.models.db import DBDownload, DBRecord, DBRecordEvent
from app.models.lidarr import CommandResponse
from app.slskd.downloads import delete_slskd_download
from app.tasks.shared import block_download


async def _lidarr_import_record(record: DBRecord, download: DBDownload) -> None:
    logger = get_soulmate_logger()

    if not settings.slskd.download_path.exists():
        logger.warning("seems like the specified slskd download path does not exist")
        return

    import_path = settings.lidarr.download_path / "soulmate" / "imports" / download.local_directory

    raw = await lidarr_api_import_record(str(import_path))
    command = CommandResponse.model_validate(raw)
    command_id = command.id

    log_data = {
        "record_artist": record.artist,
        "record_title": record.title,
        "inferred_quality": download.quality,
    }

    for _ in range(60):
        raw = await lidarr_api_get_import(command_id)
        command = CommandResponse.model_validate(raw)
        if command.status in ("completed", "failed"):
            break

        await asyncio.sleep(2)

    if command.result == "successful":
        record.state = RecordStates.imported
        await record.save()
        logger.info(
            "successfully imported record",
            **log_data,
        )
        await DBRecordEvent(record_id=record.id, event=Events.import_success).save()

        # make sure we don't process this download again
        download.state = DownloadStates.imported
        await download.save()

    elif command.status == "failed" or command.result == "unsuccessful":
        logger.warning(
            "failed to import record, see lidarr logs for further information",
            **log_data,
        )

        failed_path = settings.slskd.download_path / "soulmate" / "failed"
        os.makedirs(failed_path, exist_ok=True)

        local_directory_path = settings.slskd.download_path / "soulmate" / "imports" / download.local_directory
        if os.path.isdir(local_directory_path):
            try:
                if settings.delete_failed_imports:
                    action = "delete"
                    shutil.rmtree(local_directory_path)

                else:
                    action = "move"
                    shutil.move(
                        settings.slskd.download_path / "soulmate" / "imports" / download.local_directory,
                        failed_path / download.local_directory,
                    )

            except FileNotFoundError:
                logger.warning(
                    f"failed to {action} files of unsuccessful import",
                    **log_data,
                )

        # mark the record as wanted again
        record.state = RecordStates.manual if settings.require_manual_imports else RecordStates.wanted
        await record.save()

        # block this specific directory from being downloaded again, but let user be unblocked
        await block_download(username=download.username, directory=download.directory)

        download.state = DownloadStates.failed_import
        await download.save()
        await DBRecordEvent(record_id=record.id, event=Events.import_error).save()

    else:
        logger.error(
            "uncertain state of import",
            last_cmd_response=raw,
            command=command,
            **log_data,
        )
        return

    try:
        deleted = await delete_slskd_download(download.username, download.directory)
    except httpx.HTTPStatusError:
        deleted = False

    if not deleted:
        logger.error(
            "slskd api error: delete download",
            username=download.username,
            directory=download.directory,
        )


async def lidarr_import_records() -> None:
    records = await DBRecord.filter(state=RecordStates.downloaded)

    for record in records:
        downloads = await DBDownload.filter(
            record_id=record.id,
            state=DownloadStates.moved,
        )
        for download in downloads:
            await _lidarr_import_record(record, download)
