from fastapi import APIRouter
from fastapi.responses import JSONResponse
from tortoise.exceptions import DoesNotExist

from app.models.db import DBBlockedDownload

blocked_router = APIRouter(
    prefix="/blocked",
    tags=["blocked"],
)


def _blocked_to_dict(blocked: DBBlockedDownload) -> dict:
    return {
        "id": blocked.id,
        "username": blocked.username,
        "directory": blocked.directory,
        "created_at": blocked.created_at.isoformat(),
        "updated_at": blocked.updated_at.isoformat(),
    }


@blocked_router.get("/")
async def list_blocked() -> JSONResponse:
    """
    is this needed?
    """
    blocked = await DBBlockedDownload.all()

    return JSONResponse(
        {
            "data": [_blocked_to_dict(x) for x in blocked],
        },
        status_code=404,
    )


@blocked_router.get("/{blocked_id}")
async def get_blocked(blocked_id: int) -> JSONResponse:
    try:
        blocked = await DBBlockedDownload.get(id=blocked_id)
    except DoesNotExist:
        return JSONResponse({"status": "not found"}, status_code=404)

    return JSONResponse(
        {
            "data": _blocked_to_dict(blocked),
        },
        status_code=200,
    )


@blocked_router.delete("/{blocked_id}")
async def delete_blocked(blocked_id: int) -> JSONResponse:
    try:
        blocked = await DBBlockedDownload.get(id=blocked_id)
    except DoesNotExist:
        return JSONResponse({"status": "not found"}, status_code=404)

    await blocked.delete()

    return JSONResponse(
        {
            "data": _blocked_to_dict(blocked),
        },
        status_code=200,
        headers={
            "HX-Refresh": "true",
        },
    )
