from datetime import UTC, datetime

from fastapi import APIRouter
from fastapi.responses import JSONResponse
from tortoise.exceptions import DoesNotExist

from app.models.db import DBRecord

record_router = APIRouter(
    prefix="/records",
    tags=["records"],
)


def _record_to_dict(record: DBRecord) -> dict:
    return {
        "id": record.id,
        "artist": record.artist,
        "title": record.title,
        "release_date": record.release_date,
        "searched_times": record.searched_times,
        "next_search": record.next_search.isoformat(),
        "state": record.state,
        "source": record.source,
        "created_at": record.created_at.isoformat(),
        "updated_at": record.updated_at.isoformat(),
    }


@record_router.get("/{record_id}")
async def get_record(record_id: int) -> JSONResponse:
    try:
        record = await DBRecord.get(id=record_id)
    except DoesNotExist:
        return JSONResponse({"status": "not found"}, status_code=404)

    return JSONResponse(
        {
            "data": _record_to_dict(record),
        },
        status_code=200,
    )


@record_router.post("/{record_id}/command/reset-next-search")
async def record_command_reset_next_search(record_id: int) -> JSONResponse:
    try:
        record = await DBRecord.get(id=record_id)
    except DoesNotExist:
        return JSONResponse({"status": "not found"}, status_code=404)

    record.next_search = datetime.now(UTC)
    await record.save()

    return JSONResponse(
        {
            "data": _record_to_dict(record),
        },
        status_code=200,
    )
