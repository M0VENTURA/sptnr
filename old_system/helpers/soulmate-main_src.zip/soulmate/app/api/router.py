import httpx
from fastapi import APIRouter
from fastapi.responses import JSONResponse
from tortoise.exceptions import DoesNotExist

from app.api.blocked import blocked_router
from app.api.records import record_router
from app.constants import DownloadStates, Events, RecordStates
from app.models.api import LinkDownloadRequest
from app.models.db import DBDownload, DBRecord, DBRecordEvent
from app.slskd.downloads import get_username_downloads

api_router = APIRouter(
    prefix="/api",
    tags=[],
)

api_router.include_router(record_router)
api_router.include_router(blocked_router)


@api_router.post("/command/link-download")
async def link_slskd_download(request: LinkDownloadRequest) -> JSONResponse:
    response_404 = JSONResponse({"status": "not found"}, status_code=404)
    try:
        record = await DBRecord.get(id=request.record_id)
    except DoesNotExist:
        return response_404

    try:
        downloads = await get_username_downloads(username=request.username)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return response_404
        return JSONResponse(
            {"status": "internal error", "upstream_error": e.response.text},
            status_code=500,
        )

    download_found = False
    for directory in downloads.directories:
        if directory.directory != request.directory:
            continue
        download_found = True

    if not download_found:
        return response_404

    record.state = RecordStates.downloading
    await record.save()
    await DBRecordEvent(record_id=record.id, event=Events.download_added).save()

    # add the download as downloading, allowing soulmate to handle the moving and import automatically
    await DBDownload(
        record_id=record.id,
        username=request.username,
        directory=request.directory,
        local_directory=request.directory.rsplit("\\", 1)[-1],
        state=DownloadStates.downloading,
        quality="Unknown",
    ).save()

    return JSONResponse({"status": "created"}, status_code=201)
