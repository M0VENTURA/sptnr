import logging
import logging.config
from logging.handlers import RotatingFileHandler
from typing import Literal, TypedDict

import structlog
import structlog._frames
import structlog._log_levels
from structlog.types import EventDict, Processor

from app.config import settings


def _drop_color_message_key(logger: logging.Logger, log_method: str, event_dict: EventDict) -> EventDict:
    """
    Uvicorn logs the message a second time in the extra `color_message`, but we don't
    need it. This processor drops the key from the event dict if it exists.
    """
    event_dict.pop("color_message", None)
    return event_dict


LoggerLevel = TypedDict(
    "LoggerLevel",
    {
        "logger_name": str,
        "log_level": Literal["DEBUG", "INFO", "WARNING", "ERROR"],
    },
)


def setup_logging(
    log_level: str = "INFO",
    set_level_for_loggers: list[LoggerLevel] = [],
) -> None:
    shared_processors: list[Processor] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.stdlib.ExtraAdder(),
        _drop_color_message_key,
        structlog.processors.StackInfoRenderer(),
        structlog.processors.TimeStamper(fmt="%Y-%m-%d %H:%M:%S"),
    ]

    structlog.configure(
        processors=shared_processors  # noqa: RUF005
        + [
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        # These run ONLY on `logging` entries that do NOT originate within
        # structlog.
        foreign_pre_chain=shared_processors,
        # These run on ALL entries after the pre_chain is done.
        processors=[
            # Remove _record & _from_structlog.
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            structlog.dev.ConsoleRenderer(),
        ],
    )

    json_formatter = structlog.stdlib.ProcessorFormatter(
        # These run ONLY on `logging` entries that do NOT originate within
        # structlog.
        foreign_pre_chain=shared_processors,
        # These run on ALL entries after the pre_chain is done.
        processors=[
            structlog.processors.format_exc_info,
            structlog.processors.CallsiteParameterAdder(
                [
                    structlog.processors.CallsiteParameter.FILENAME,
                    structlog.processors.CallsiteParameter.FUNC_NAME,
                    structlog.processors.CallsiteParameter.LINENO,
                ]
            ),
            # Remove _record & _from_structlog.
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            structlog.processors.JSONRenderer(),
        ],
    )

    # Use OUR formatter to format all `logging` entries.
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    root_logger = logging.getLogger()
    root_logger.addHandler(handler)
    root_logger.setLevel("INFO")

    logs_path = settings.config_path / "logs"
    logs_path.mkdir(parents=True, exist_ok=True)

    file_handler = RotatingFileHandler(logs_path / "soulmate.log", maxBytes=10485760, backupCount=5)
    file_handler.setFormatter(json_formatter)

    logger = logging.getLogger("soulmate")
    logger.addHandler(file_handler)
    logger.setLevel(log_level)

    for logger_name in logging.root.manager.loggerDict:
        for logger_level in set_level_for_loggers:
            if logger_name.startswith(logger_level["logger_name"]):
                logging.getLogger(logger_name).setLevel(logger_level["log_level"])

    for _log_name, propagate in [("uvicorn", True), ("uvicorn.error", True), ("uvicorn.access", False)]:
        logging.getLogger(_log_name).handlers.clear()
        logging.getLogger(_log_name).propagate = propagate
