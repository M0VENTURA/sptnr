import structlog


def get_soulmate_logger() -> structlog.BoundLogger:
    return structlog.get_logger("soulmate")
