import time
from typing import Awaitable, Callable

import structlog
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from uvicorn.protocols.utils import get_path_with_query_string


class SoulmateFastAPIMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: Callable[[Request], Awaitable[Response]]) -> Response:
        logger = structlog.get_logger("soulmate.access")
        structlog.contextvars.clear_contextvars()

        start_time = time.perf_counter_ns()

        response = Response(status_code=500)
        try:
            response = await call_next(request)
        except Exception:
            structlog.stdlib.get_logger("soulmate.error").exception("Uncaught exception")
            raise

        finally:
            process_time_nanoseconds = time.perf_counter_ns() - start_time
            process_time = str(round(process_time_nanoseconds / 10**9, 2))
            status_code = response.status_code
            url = get_path_with_query_string(request.scope)  # type: ignore

            if request.client:
                client_host = request.client.host
                client_port = request.client.port
            else:
                client_host = ""
                client_port = 0

            http_method = request.method
            http_version = request.scope["http_version"]

            url = url.replace("%", "%%")
            if not any(
                [
                    url.startswith(x)
                    for x in (
                        "/_/health",
                        "/docs",
                        "/openapi.json",
                        "/favicon.ico",
                        "/static",
                        "/gui",
                        "/apple-touch-icon-precomposed.pn",
                        "/apple-touch-icon.png",
                    )
                ]
            ):
                logger.info(f'{client_host}:{client_port} - "{http_method} {url} HTTP/{http_version}" {status_code}')

            response.headers["X-Process-Time"] = process_time
            return response
