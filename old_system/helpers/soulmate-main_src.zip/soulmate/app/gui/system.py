from datetime import UTC, datetime

import httpx

from app.config import settings
from app.gui.shared import format_time, frontend_timestamp
from app.lidarr.api import lidarr_api_get_connection_status
from app.slskd.api import slskd_api_get_connection_status
from app.tasks.scheduler import scheduler
from app.version import soulmate_version


async def get_gui_system_data() -> dict:
    lidarr_data = {
        "name": "Lidarr",
        "icon": "",
        "status": "",
        "color": "",
    }
    try:
        lidarr_version = await lidarr_api_get_connection_status()
        if lidarr_version == "v1":
            lidarr_data["status"] = "Connected"
            lidarr_data["icon"] = "check_circle"
            lidarr_data["color"] = "green600"
        else:
            lidarr_data["status"] = f"Incorrect API version ({lidarr_version})"
            lidarr_data["icon"] = "error"
            lidarr_data["color"] = "red600"

    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            lidarr_data["status"] = "Authentication failed"
            lidarr_data["icon"] = "warning"
            lidarr_data["color"] = "orange600"
        else:
            lidarr_data["status"] = "Lidarr server error"
            lidarr_data["icon"] = "error"
            lidarr_data["color"] = "red600"

    except (httpx.ConnectError, httpx.UnsupportedProtocol):
        lidarr_data["status"] = "Unreachable"
        lidarr_data["icon"] = "error"
        lidarr_data["color"] = "red600"

    slskd_data = {
        "name": "slskd",
        "icon": "",
        "status": "",
        "color": "",
    }
    try:
        slskd_server_data = await slskd_api_get_connection_status()
        if slskd_server_data.get("isConnected") is True and slskd_server_data.get("isLoggedIn") is True:
            slskd_data["status"] = "Connected"
            slskd_data["icon"] = "check_circle"
            slskd_data["color"] = "green600"
        else:
            slskd_data["status"] = "slskd seems to be running but not connected/logged in"
            slskd_data["icon"] = "warning"
            slskd_data["color"] = "orange600"

    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            slskd_data["status"] = "Authentication failed"
            slskd_data["icon"] = "warning"
            slskd_data["color"] = "orange600"
        else:
            slskd_data["status"] = "slskd server error"
            slskd_data["icon"] = "error"
            slskd_data["color"] = "red600"

    except (httpx.ConnectError, httpx.UnsupportedProtocol):
        slskd_data["status"] = "Unreachable"
        slskd_data["icon"] = "error"
        slskd_data["color"] = "red600"

    connections = [
        lidarr_data,
        slskd_data,
    ]

    job_sorter = {
        "task_update_lidarr_wanted_records": 1,
        "task_search_and_download_records": 2,
        "task_update_download_states": 3,
        "task_move_completed_downloads": 4,
        "task_lidarr_import_records": 5,
        "task_cleanup_slskd": 6,
        "task_cleanup_database": 7,
    }
    tasks = []
    for job in sorted(scheduler.get_jobs(), key=lambda x: job_sorter.get(x.name) or 99):
        tasks.append(
            {
                "name": job.name.replace("task_", "").replace("_", " "),
                "next_run_time": frontend_timestamp(job.next_run_time, include_date=False),
                "time_left": format_time((job.next_run_time - datetime.now(UTC)).seconds),
            }
        )

    errors = []
    if not settings.slskd.download_path.exists():
        errors.append(
            {
                "text": f"Path '{settings.slskd.download_path}' is specified as the slskd download path, but does not seem to exist",
                "level": "danger",
            }
        )

    for setting, readable in [
        (settings.lidarr.url, "Lidarr URL (LIDARR__URL)"),
        (settings.lidarr.key, "Lidarr API key (LIDARR__KEY)"),
        (settings.lidarr.download_path, "Lidarr download path (LIDARR__DOWNLOAD_PATH)"),
        (settings.slskd.url, "slskd URL (SLSKD__URL)"),
        (settings.slskd.key, "slskd API key (SLSKD__KEY)"),
        (settings.slskd.download_path, "slskd download path (SLSKD__DOWNLOAD_PATH)"),
    ]:
        if not setting:
            errors.append(
                {
                    "text": f"{readable} is not configured",
                    "level": "danger",
                }
            )

    info = {
        "version": soulmate_version(),
        "config path": settings.config_path,
        "slskd download path": settings.slskd.download_path,
        "source": "https://codeberg.org/banankungen/soulmate",
    }

    return {
        "connections": connections,
        "tasks": tasks,
        "errors": errors,
        "info": info,
    }
