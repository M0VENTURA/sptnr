from datetime import datetime


def format_time(duration_in_sec: int) -> str:
    seconds = duration_in_sec % 60
    duration_in_min = int(duration_in_sec / 60)
    minutes = duration_in_min % 60
    hours = int((duration_in_min - minutes) / 60)

    timestring = []
    if hours:
        timestring.append(f"{hours}h")
    if minutes:
        timestring.append(f"{minutes}m")

    if seconds:
        timestring.append(f"{seconds}s")

    return " ".join(timestring)


def frontend_timestamp(t: datetime, include_date: bool = True) -> str:
    if include_date:
        return t.astimezone(tz=None).strftime("%Y-%m-%d %H:%M:%S")

    return t.astimezone(tz=None).strftime("%H:%M:%S")
