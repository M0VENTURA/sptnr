from pathlib import Path

import jinja2
from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from tortoise.exceptions import DoesNotExist

from app.config import settings
from app.constants import DownloadStates, Events, RecordStates
from app.gui.shared import frontend_timestamp
from app.gui.system import get_gui_system_data
from app.models.db import DBBlockedDownload, DBDownload, DBRecord, DBRecordEvent

jinja2_env = jinja2.Environment(
    loader=jinja2.FileSystemLoader(Path(__file__).parent / "templates"),
    autoescape=jinja2.select_autoescape(["html", "xml"]),
)

gui_router = APIRouter(
    prefix="/gui",
    tags=[],
)


@gui_router.get("/records", include_in_schema=False)
async def get_records_page(show_all: bool = False) -> HTMLResponse:
    template = jinja2_env.get_template("records.html.j2")

    icons = {
        RecordStates.downloaded: "download",
        RecordStates.downloading: "downloading",
        RecordStates.imported: "check_circle",
        RecordStates.manual: "call_to_action",
        RecordStates.removed: "block",
        RecordStates.wanted: "queue_music",
    }
    colors = {
        RecordStates.downloaded: "green400",
        RecordStates.downloading: "orange600",
        RecordStates.imported: "green600",
        RecordStates.manual: "orange600",
        RecordStates.removed: "brown600",
        RecordStates.wanted: "",
    }

    sort_order = {
        RecordStates.downloaded: 3,
        RecordStates.downloading: 2,
        RecordStates.imported: 90,
        RecordStates.manual: 1,
        RecordStates.removed: 99,
        RecordStates.wanted: 4,
    }

    records = await DBRecord.all()
    data = {
        "records": [],
        "stats": {
            "missing": {
                "count": 0,
                "icon": "queue_music",
                "title": "Missing",
                "external_link": "/gui/records",
                "link_target": "_self",
            },
            "unmet": {
                "count": 0,
                "icon": "upgrade",
                "title": "Unmet",
                "external_link": "/gui/records",
                "link_target": "_self",
            },
            "in_progress": {
                "count": 0,
                "icon": "downloading",
                "title": "Progress",
                "external_link": (settings.slskd.public_url or settings.slskd.url) + "/downloads",
                "link_target": "_blank",
            },
            "imported": {
                "count": 0,
                "icon": "check_circle",
                "title": "Imported",
                "external_link": "/gui/records?show_all=true",
                "link_target": "_self",
            },
            "removed": {
                "count": 0,
                "icon": "check_circle",
                "title": "Removed",
                "external_link": "/gui/records?show_all=true",
                "link_target": "_self",
            },
            "manual": {
                "count": 0,
                "icon": "call_to_action",
                "title": "Manual",
                "external_link": (settings.lidarr.public_url or settings.lidarr.url) + "/activity/queue",
                "link_target": "_blank",
            },
        },
    }
    if not settings.require_manual_imports:
        del data["stats"]["manual"]

    for r in sorted(records, key=lambda x: str(sort_order[x.state]).zfill(5) + x.source + f"{x.artist} - {x.title}"):
        match r.state:
            case RecordStates.wanted:
                category = r.source
            case RecordStates.downloading | RecordStates.downloaded:
                category = "in_progress"
            case RecordStates.imported | RecordStates.removed:
                category = r.state
            case RecordStates.manual:
                category = "manual"
            case _:
                category = ""

        if category:
            data["stats"][category]["count"] += 1

        if r.state in (RecordStates.imported, RecordStates.removed) and show_all is False:
            continue

        icon = icons.get(r.state, "question_mark")
        if r.state == RecordStates.wanted and r.source == "unmet":
            icon = "upgrade"

        row = {
            "id": r.id,
            "title": r.title,
            "artist": r.artist,
            "release_date": r.release_date[0:4],
            "color": colors.get(r.state, "yellow600"),
            "icon": icon,
        }

        data["records"].append(row)

    return HTMLResponse(template.render(data=data))


@gui_router.get("/system", include_in_schema=False)
async def get_tasks_page() -> HTMLResponse:
    template = jinja2_env.get_template("system.html.j2")
    return HTMLResponse(template.render(data=await get_gui_system_data()))


@gui_router.get("/record/{record_id}", include_in_schema=False)
async def get_record_page(record_id: int) -> HTMLResponse:
    template = jinja2_env.get_template("record.html.j2")

    try:
        record = await DBRecord.get(id=record_id)
    except DoesNotExist:
        raise HTTPException(status_code=404)

    event_copy = {
        Events.download_added: "Download added",
        Events.download_error: "Download error occured",
        Events.download_stalled: "Download was stalled",
        Events.download_success: "Download successful!",
        Events.import_error: "Import failed",
        Events.import_success: "Import successful!",
        Events.import_lidarr: "Import by lidarr",
        Events.removed: "Removed from wanted in Lidarr, this usually means it was either unmonitored or imported via other means than soulmate",
        Events.search_performed: "Search performed",
        Events.wanted_missing: "Added record as wanted (missing)",
        Events.wanted_unmet: "Added record as wanted (cutoff unmet)",
    }

    log = []

    events = await DBRecordEvent.filter(record_id=record_id)

    for event in sorted(events, key=lambda x: x.created_at, reverse=True):
        timestamp = frontend_timestamp(event.created_at)
        log.append(
            {
                "timestamp": timestamp,
                "text": event_copy.get(event.event, event.event),
            }
        )

    data = {
        "artist": record.artist,
        "title": record.title,
        "year": record.release_date[:4],
        "release_date": record.release_date[:10],
        "record_id": record.id,
        "state": record.state.capitalize(),
        "searched_times": record.searched_times,
        "next_search": frontend_timestamp(record.next_search),
        "log": sorted(log, key=lambda x: x["timestamp"], reverse=True),
    }

    return HTMLResponse(template.render(data=data))


@gui_router.get("/blocked", include_in_schema=False)
async def get_blocked_page() -> HTMLResponse:
    template = jinja2_env.get_template("blocked.html.j2")
    data = []
    blocked_list = await DBBlockedDownload.all()
    for blocked in sorted(blocked_list, key=lambda x: f"{x.username}--{x.directory}"):
        data.append(
            {
                "id": blocked.id,
                "username": blocked.username,
                "directory": blocked.directory,
                "created_at": frontend_timestamp(blocked.created_at),
            }
        )

    return HTMLResponse(template.render(data=data))


@gui_router.get("/downloads", include_in_schema=False)
async def get_downloads_page() -> HTMLResponse:
    template = jinja2_env.get_template("downloads.html.j2")
    data = []
    records = await DBRecord.filter(state__in=(RecordStates.downloading, RecordStates.downloaded))
    for record in sorted(records, key=lambda x: f"{x.artist}--{x.title}"):
        downloads = await DBDownload.filter(record_id=record.id)
        for download in sorted(downloads, key=lambda x: x.id):
            if download.state not in (DownloadStates.success, DownloadStates.moved, DownloadStates.downloading):
                continue

            data.append(
                {
                    "record_id": record.id,
                    "record_artist": record.artist,
                    "record_title": record.title,
                    "slskd_username": download.username,
                    "slskd_directory": download.directory,
                    "progress": download.progress,
                }
            )

    return HTMLResponse(template.render(data=data))
