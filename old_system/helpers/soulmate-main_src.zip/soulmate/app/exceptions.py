class MaxConcurrentDownloadsReachedError(Exception):
    pass


class SLSKDAPIError(Exception):
    pass
