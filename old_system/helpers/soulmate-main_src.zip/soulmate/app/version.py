import tomllib
from functools import cache
from pathlib import Path


@cache
def soulmate_version() -> str:
    with open(Path(__file__).parent.parent.parent / "pyproject.toml") as toml_file:
        data = tomllib.loads(toml_file.read())

    return data["project"]["version"]
