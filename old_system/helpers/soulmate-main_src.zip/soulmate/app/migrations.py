import sqlite3

from app.config import settings


def run_migrations() -> None:
    db_path = settings.config_path / "soulmate.db"

    write_current_version = False
    if not db_path.exists():
        write_current_version = True

    connection = sqlite3.connect(db_path)
    cursor = connection.cursor()

    # if the db doesnt exist, let's update with the currect version of the db
    # this avoid trying to run migrations on newly created db's
    if write_current_version:
        # update with current version in the string
        cursor.execute("PRAGMA user_version = 0")

    migration_done = False

    while not migration_done:
        cursor.execute("PRAGMA user_version")
        result = cursor.fetchall()
        version = result[0][0]

        match version:
            case 0:
                migration_done = True

    connection.commit()
    connection.close()
